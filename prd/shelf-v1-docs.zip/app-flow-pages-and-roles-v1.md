# app-flow-pages-and-roles.md (V1 Only)

## Site Map

-   Login
-   Library
-   Item Detail
-   Project View
-   Settings

------------------------------------------------------------------------

## User Role

Single Role: Owner

Full permissions. No sharing. No multi-user.

------------------------------------------------------------------------

## Primary Flows

### Save via Telegram

1.  Send URL/file/voice
2.  Bot confirms "Saved ✓"
3.  Review later in app

### Save via Extension

1.  Click extension
2.  Auto-save
3.  Confirmation toast

### Consume Item

1.  Open library
2.  Open item
3.  Mark as Done
