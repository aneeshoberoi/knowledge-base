# design-guidelines.md (V1 Only)

## Emotional Tone

Quiet, focused, respectful of attention.

------------------------------------------------------------------------

## Typography

H1 32px / 600\
H2 24px / 600\
H3 18px / 500\
Body 16px / 400\
Caption 13px / 400

Line-height ≥ 1.6

------------------------------------------------------------------------

## Color System

Primary: #111111\
Secondary: #6B7280\
Background: #FFFFFF\
Muted Surface: #F3F4F6\
Accent: #2563EB\
Success: #16A34A\
Error: #DC2626

Contrast ≥ 4.5:1

------------------------------------------------------------------------

## Interaction Rules

-   Status toggle subtle animation (≤250ms)
-   Toast confirmations minimal ("Saved ✓")
-   No celebration effects
-   One primary CTA per screen

------------------------------------------------------------------------

## Accessibility

-   Semantic structure
-   Keyboard navigation
-   Visible focus states
-   Touch targets ≥44px

------------------------------------------------------------------------

## Emotional Guardrails

-   No unread counters
-   No streaks
-   No guilt language
-   Calm, direct microcopy
