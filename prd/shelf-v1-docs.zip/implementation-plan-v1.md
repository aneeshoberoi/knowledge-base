# implementation-plan.md (V1 Only)

## Phase 1 --- Foundation

-   Create Next.js project
-   Configure Vercel deployment
-   Set up Supabase (DB + Auth)
-   Enable Magic Link
-   Create base schema (items, projects, tags, snippets, file_assets)

------------------------------------------------------------------------

## Phase 2 --- Core UI

-   Build list view (pagination + filters)
-   Build item detail view
-   Implement status toggle
-   Implement notes editing
-   Implement archive/delete

------------------------------------------------------------------------

## Phase 3 --- Capture APIs

-   Unified /api/capture endpoint
-   Duplicate detection (URL hash + file checksum)
-   Async enrichment pipeline
-   LLM classification + tagging
-   Open Graph metadata fetcher
-   Read-time estimation

------------------------------------------------------------------------

## Phase 4 --- Telegram Bot

-   Register bot + webhook
-   URL handling
-   File upload handling
-   Voice transcription (Whisper)
-   Intent parsing (LLM)
-   Confirmation response

------------------------------------------------------------------------

## Phase 5 --- Browser Capture

-   Chrome extension scaffold
-   Bookmarklet script
-   Save confirmation flow

------------------------------------------------------------------------

## Phase 6 --- Storage + OCR

-   Configure blob storage
-   Store file assets
-   Run OCR for images
-   Store extracted text for search

------------------------------------------------------------------------

## Phase 7 --- PWA

-   Add manifest
-   Add service worker
-   Cache last 50 items for offline reading
