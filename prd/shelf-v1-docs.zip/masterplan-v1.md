# masterplan.md (V1 Only)

## Elevator Pitch

Shelf is a single-user PWA that captures links, files, and voice notes
in seconds.

It automatically understands what you saved --- type, project, and tags
--- without requiring manual organization.

V1 focuses strictly on capture, clean library management, and calm
consumption.

------------------------------------------------------------------------

## Scope (V1)

-   Zero-friction capture (Share Sheet, Extension, Bookmarklet,
    Telegram)
-   Automatic type detection, project assignment, and tagging
-   Cross-device sync
-   Library list with filtering and pagination
-   Item detail view with status toggle
-   Projects management
-   Snippet capture (Telegram voice)
-   File storage with OCR
-   Google OAuth authentication (single user)

------------------------------------------------------------------------

## Explicitly Out of Scope (V1)

-   Contextual surfacing engine
-   Calendar integration
-   Daily check-ins
-   Item sharing
-   Multi-user support
-   Knowledge graph
-   External content discovery

------------------------------------------------------------------------

## Core Architecture

Layers: - Capture Layer - Ingest Layer - Intelligence Layer - Storage
Layer - UI Layer

Technology: - Next.js (App Router) - Google Sheets API v4 (metadata
store) + Google OAuth (auth) - S3-compatible storage (binary files
only) - Telegram Bot API (webhook) - Whisper API - claude-haiku-4-5
for tagging and classification

Spreadsheet structure: One master spreadsheet with tabs: `items`,
`projects`, `tags`, `snippets`. Spreadsheet ID and service account
credentials stored as environment variables.

Trade-offs: No full-text search in V1 (client-side filtering on
fetched rows). Google Sheets API rate limit is 300 req/min ---
sufficient for single-user usage. Binary files (PDFs, images, voice)
are stored in S3-compatible storage, not in Sheets.
