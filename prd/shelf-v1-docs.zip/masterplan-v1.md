# masterplan.md (V1 Only)

## Elevator Pitch

Shelf is a single-user PWA that captures links, files, and voice notes
in seconds.

It automatically understands what you saved --- type, project, and tags
--- without requiring manual organization.

V1 focuses strictly on capture, clean library management, and calm
consumption.

------------------------------------------------------------------------

## Scope (V1)

-   Zero-friction capture (Share Sheet, Extension, Bookmarklet,
    Telegram)
-   Automatic type detection, project assignment, and tagging
-   Cross-device sync
-   Library list with filtering and pagination
-   Item detail view with status toggle
-   Projects management
-   Snippet capture (Telegram voice)
-   File storage with OCR
-   Magic link authentication (single user)

------------------------------------------------------------------------

## Explicitly Out of Scope (V1)

-   Contextual surfacing engine
-   Calendar integration
-   Daily check-ins
-   Item sharing
-   Multi-user support
-   Knowledge graph
-   External content discovery

------------------------------------------------------------------------

## Core Architecture

Layers: - Capture Layer - Ingest Layer - Intelligence Layer - Storage
Layer - UI Layer

Technology: - Next.js (App Router) - Supabase (Postgres + Magic Link) -
S3-compatible storage - Telegram Bot API (webhook) - Whisper API -
claude-haiku-4-5 for tagging and classification
